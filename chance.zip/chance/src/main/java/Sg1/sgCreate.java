package Sg1;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class sgCreate
 */
@WebServlet("/SignUp")
public class sgCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		String name = request.getParameter("username");
		String pass1 = request.getParameter("password");
		try{
			  
		    Class.forName("com.mysql.cj.jdbc.Driver");
		    Connection x = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","");
		    PreparedStatement pst = x.prepareStatement("create table "+name+"(Student varchar(30),course varchar(30),Fee int(20))");
		    PreparedStatement pst1 = x.prepareStatement("insert into earth (sname,pass) values('"+name+"','"+pass1+"')");
		    int z = pst.executeUpdate();
		    System.out.println(z+"Table created!!!");
		    System.out.println(pst1.executeUpdate()+" Instructor is added");
		    if(z == 0) {
		    	HttpSession session = request.getSession();
                session.setAttribute("Uname",name);
		    	response.sendRedirect("Practice1.jsp");
		    }
		    
		 }catch(Exception e){
			 System.out.println("error is created in sgCreate page");
			 response.sendRedirect("Error.jsp");
		 }	
	}

}
