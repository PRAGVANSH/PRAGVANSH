package Sg1;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.*;
/**
 * Servlet implementation class studentData
 */
@WebServlet("/Student")
public class studentData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			PrintWriter out = response.getWriter();
			String student = request.getParameter("username");
			String course = request.getParameter("course");
			String fee = request.getParameter("fee");
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","");
//-------------------------------------
			PreparedStatement pst = cn.prepareStatement("insert into suraj (Student,Course,fee) values('"+student+"','"+course+"','"+fee+"')");
			int x = pst.executeUpdate();
		    if(x == 1) {
		    	response.sendRedirect("SucessEnroll.jsp");
		    }
             pst.close();
             cn.close();
		} catch (Exception e) {
		System.out.println(e+" Error created");
	    }

    // HttpSession session = request.getSession();
     //session.setAttribute("Students",x1);
     
		//---------------------------------------
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
   }
}
